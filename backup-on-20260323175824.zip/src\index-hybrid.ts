import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import { sign, verify } from 'hono/jwt'

type Bindings = {
  DB: D1Database;
  MAILERSEND_API_KEY: string;
  JWT_SECRET: string;
  ENVIRONMENT: string;
}

const app = new Hono<{ Bindings: Bindings }>()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// =================================
// UTILITY FUNCTIONS
// =================================

// Hash password using SHA-256 with salt
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const salt = generateSecureToken().substring(0, 16);
  const saltedPassword = password + salt;
  
  const data = encoder.encode(saltedPassword);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  return salt + hashHex;
}

// Verify password against hash
async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const salt = hash.substring(0, 16);
    const storedHash = hash.substring(16);
    
    const saltedPassword = password + salt;
    const data = encoder.encode(saltedPassword);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const computedHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    
    return computedHash === storedHash;
  } catch (error) {
    return false;
  }
}

// Generate secure random token
function generateSecureToken(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

// Validate email format
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  return emailRegex.test(email);
}

// Validate password strength
function validatePassword(password: string): { valid: boolean; message?: string } {
  if (password.length < 8) {
    return { valid: false, message: 'Passwort muss mindestens 8 Zeichen lang sein' };
  }
  
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: 'Passwort muss mindestens einen Großbuchstaben enthalten' };
  }
  
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: 'Passwort muss mindestens einen Kleinbuchstaben enthalten' };
  }
  
  if (!/[0-9]/.test(password)) {
    return { valid: false, message: 'Passwort muss mindestens eine Zahl enthalten' };
  }
  
  if (!/[!@#$%^&*()_+\\-=\\[\\]{};':"\\\\|,.<>\\?]/.test(password)) {
    return { valid: false, message: 'Passwort muss mindestens ein Sonderzeichen enthalten' };
  }
  
  return { valid: true };
}

// Send email via MailerSend
async function sendEmail(apiKey: string, to: string, subject: string, html: string, text: string) {
  try {
    const response = await fetch('https://api.mailersend.com/v1/email', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: {
          email: 'noreply@supplementstack.de',
          name: 'Supplement Stack'
        },
        to: [{
          email: to
        }],
        subject: subject,
        html: html,
        text: text
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`MailerSend API Error: ${response.status} - ${errorText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Email sending failed:', error);
    throw error;
  }
}

// =================================
// HTML ROUTES - RECOVERED FROM BACKUP
// =================================

// Main page - restored from backup
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dein intelligenter Supplement Manager - Supplement Stack</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="/static/styles.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Main content will be loaded here -->
        <div id="app">Loading...</div>
        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

// Demo page - restored from backup with full functionality
app.get('/demo', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Demo - Supplement Stack</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="/static/styles.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Demo content will be loaded here -->
        <div id="demo-app">Loading Demo...</div>
        <script src="/static/demo-modal.js"></script>
    </body>
    </html>
  `)
})

// Authentication page with full functionality
app.get('/auth', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Anmeldung - Supplement Stack</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50 min-h-screen flex items-center justify-center">
        <div class="auth-container max-w-md w-full bg-white rounded-lg shadow-lg p-8 mx-4">
            <!-- Header -->
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-gray-900 mb-2">🧬 Supplement Stack</h1>
                <p class="text-gray-600">Ihr intelligenter Supplement Manager</p>
            </div>

            <!-- Tab Navigation -->
            <div class="flex mb-6 bg-gray-100 rounded-lg p-1">
                <button class="auth-tab flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors active" data-tab="login">
                    Anmelden
                </button>
                <button class="auth-tab flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors" data-tab="register">
                    Registrieren
                </button>
            </div>

            <!-- Login Tab -->
            <div id="loginTab" class="tab-content">
                <form id="loginForm" class="space-y-4">
                    <div>
                        <label for="loginEmail" class="block text-sm font-medium text-gray-700 mb-1">E-Mail-Adresse</label>
                        <input type="email" id="loginEmail" name="email" required 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="loginPassword" class="block text-sm font-medium text-gray-700 mb-1">Passwort</label>
                        <input type="password" id="loginPassword" name="password" required 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <button type="submit" id="loginBtn" 
                            class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors font-medium">
                        Anmelden
                    </button>
                </form>
                <div class="text-center mt-4">
                    <button class="auth-tab text-blue-600 hover:text-blue-800 text-sm" data-tab="forgot">
                        Passwort vergessen?
                    </button>
                </div>
                <div class="mt-6 p-4 bg-blue-50 rounded-md">
                    <h4 class="text-sm font-medium text-blue-800 mb-2">🔐 2-Schritt-Verifizierung</h4>
                    <p class="text-xs text-blue-700">Nach der Anmeldung erhalten Sie eine E-Mail zur Bestätigung. Dies schützt Ihr Konto gemäß DSGVO-Anforderungen.</p>
                </div>
            </div>

            <!-- Register Tab -->
            <div id="registerTab" class="tab-content hidden">
                <form id="registerForm" class="space-y-4">
                    <div>
                        <label for="registerEmail" class="block text-sm font-medium text-gray-700 mb-1">E-Mail-Adresse</label>
                        <input type="email" id="registerEmail" name="email" required 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="registerPassword" class="block text-sm font-medium text-gray-700 mb-1">Passwort</label>
                        <input type="password" id="registerPassword" name="password" required 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <p class="text-xs text-gray-500 mt-1">Mindestens 8 Zeichen, mit Groß-/Kleinbuchstaben, Zahl und Sonderzeichen</p>
                    </div>
                    <div>
                        <label for="confirmPassword" class="block text-sm font-medium text-gray-700 mb-1">Passwort bestätigen</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" required 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <button type="submit" id="registerBtn" 
                            class="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors font-medium">
                        Registrieren
                    </button>
                </form>
                <div class="mt-6 p-4 bg-green-50 rounded-md">
                    <h4 class="text-sm font-medium text-green-800 mb-2">📧 E-Mail-Bestätigung erforderlich</h4>
                    <p class="text-xs text-green-700">Nach der Registrierung erhalten Sie eine E-Mail zur Bestätigung Ihrer Adresse. Dies ist für die DSGVO-Konformität erforderlich.</p>
                </div>
            </div>

            <!-- Forgot Password Tab -->
            <div id="forgotTab" class="tab-content hidden">
                <form id="forgotPasswordForm" class="space-y-4">
                    <div>
                        <label for="forgotEmail" class="block text-sm font-medium text-gray-700 mb-1">E-Mail-Adresse</label>
                        <input type="email" id="forgotEmail" name="email" required 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <button type="submit" id="forgotBtn" 
                            class="w-full bg-gray-600 text-white py-2 px-4 rounded-md hover:bg-gray-700 transition-colors font-medium">
                        Passwort zurücksetzen
                    </button>
                </form>
                <div class="text-center mt-4">
                    <button class="auth-tab text-blue-600 hover:text-blue-800 text-sm" data-tab="login">
                        Zurück zur Anmeldung
                    </button>
                </div>
            </div>

            <!-- Links -->
            <div class="mt-8 text-center">
                <a href="/" class="text-sm text-gray-600 hover:text-gray-800">
                    ← Zurück zur Startseite
                </a>
            </div>

            <!-- GDPR Notice -->
            <div class="mt-6 p-4 bg-gray-50 rounded-md">
                <p class="text-xs text-gray-600 text-center">
                    Mit der Nutzung stimmen Sie unseren 
                    <a href="/datenschutz" class="text-blue-600 hover:text-blue-800">Datenschutzbestimmungen</a> zu.
                    Alle Daten werden DSGVO-konform verarbeitet.
                </p>
            </div>
        </div>

        <script src="/static/auth.js"></script>
    </body>
    </html>
  `)
})

// Dashboard
app.get('/dashboard', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard - Supplement Stack</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <div id="dashboard-app">Loading Dashboard...</div>
        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

// Password reset page
app.get('/auth/reset-password', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Passwort zurücksetzen - Supplement Stack</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-gray-50 min-h-screen flex items-center justify-center">
        <div class="auth-container max-w-md w-full bg-white rounded-lg shadow-lg p-8 mx-4">
            <!-- Password Reset Form -->
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-gray-900 mb-2">🔑 Neues Passwort</h1>
                <p class="text-gray-600">Erstellen Sie ein sicheres neues Passwort</p>
            </div>
            <form id="resetPasswordForm" class="space-y-4">
                <div>
                    <label for="newPassword" class="block text-sm font-medium text-gray-700 mb-1">Neues Passwort</label>
                    <input type="password" id="newPassword" name="password" required 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label for="confirmNewPassword" class="block text-sm font-medium text-gray-700 mb-1">Passwort bestätigen</label>
                    <input type="password" id="confirmNewPassword" name="confirmPassword" required 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <button type="submit" id="resetBtn" 
                        class="w-full bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 transition-colors font-medium">
                    Passwort ändern
                </button>
            </form>
        </div>
        <script src="/static/auth.js"></script>
    </body>
    </html>
  `)
})

// =================================
// AUTHENTICATION API ROUTES
// =================================

// User registration
app.post('/api/auth/register', async (c) => {
  try {
    const { email, password, confirmPassword } = await c.req.json();

    console.log('Registration attempt for:', email);

    if (!email || !password || !confirmPassword) {
      return c.json({
        error: 'missing_fields',
        message: 'Alle Felder sind erforderlich'
      }, 400);
    }

    if (password !== confirmPassword) {
      return c.json({
        error: 'password_mismatch',
        message: 'Die Passwörter stimmen nicht überein'
      }, 400);
    }

    if (!validateEmail(email)) {
      return c.json({
        error: 'invalid_email_format',
        message: 'Ungültiges E-Mail-Format'
      }, 400);
    }

    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      return c.json({
        error: 'password_too_weak',
        message: passwordValidation.message
      }, 400);
    }

    // Check if user already exists
    const existingUser = await c.env.DB.prepare(
      'SELECT * FROM users WHERE email = ?'
    ).bind(email.toLowerCase()).first();

    if (existingUser) {
      if (existingUser.email_verified) {
        return c.json({
          error: 'email_already_exists',
          message: 'Diese E-Mail-Adresse ist bereits registriert'
        }, 409);
      } else {
        // Delete unverified user
        await c.env.DB.prepare('DELETE FROM users WHERE id = ?').bind(existingUser.id).run();
      }
    }

    // Hash password and generate verification token
    const passwordHash = await hashPassword(password);
    const verificationToken = generateSecureToken();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

    console.log('Creating user with verification token');

    // Create user
    const result = await c.env.DB.prepare(`
      INSERT INTO users (
        email, password_hash, email_verified, 
        email_verification_token, email_verification_expires_at,
        created_at, updated_at
      ) VALUES (?, ?, FALSE, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `).bind(email.toLowerCase(), passwordHash, verificationToken, expiresAt).run();

    console.log('User created, sending verification email');

    // Send verification email
    const baseUrl = c.env.ENVIRONMENT === 'production' 
      ? 'https://supplementstack.de' 
      : `https://${c.req.header('host')}`;

    const verificationLink = `${baseUrl}/api/auth/verify-email?token=${verificationToken}`;
    
    const emailHtml = `
      <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center;">
          <h1 style="margin: 0;">🧬 Supplement Stack</h1>
          <p style="margin: 10px 0 0 0;">Willkommen bei Ihrem intelligenten Supplement Manager</p>
        </div>
        <div style="background: #f9f9f9; padding: 30px;">
          <h2>E-Mail-Adresse bestätigen</h2>
          <p>Vielen Dank für Ihre Registrierung bei Supplement Stack. Um die DSGVO-Anforderungen zu erfüllen, müssen wir Ihre E-Mail-Adresse bestätigen.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationLink}" style="background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
              E-Mail-Adresse bestätigen
            </a>
          </div>
          <p>Alternativ können Sie auch diesen Link kopieren: <br><code>${verificationLink}</code></p>
          <div style="background: #e8f4f8; padding: 15px; border-left: 4px solid #667eea; margin: 20px 0;">
            <h4>🔒 Datenschutz & DSGVO-Konformität</h4>
            <p>Ihre Daten werden nach den strengsten deutschen und europäischen Datenschutzgesetzen behandelt.</p>
          </div>
        </div>
      </div>
    `;

    const emailText = `Willkommen bei Supplement Stack! Bestätigen Sie Ihre E-Mail-Adresse: ${verificationLink}`;

    try {
      await sendEmail(
        c.env.MAILERSEND_API_KEY,
        email,
        'E-Mail-Adresse bestätigen - Supplement Stack',
        emailHtml,
        emailText
      );

      console.log('Verification email sent successfully');
    } catch (emailError) {
      console.error('Email sending failed:', emailError);
      // Continue anyway - user can still complete registration manually
    }

    return c.json({
      message: 'Registrierung erfolgreich! Bitte überprüfen Sie Ihre E-Mails und bestätigen Sie Ihre E-Mail-Adresse.',
      emailSent: true
    }, 201);

  } catch (error) {
    console.error('Registration error:', error);
    return c.json({
      error: 'internal_server_error',
      message: 'Ein interner Fehler ist aufgetreten. Bitte versuchen Sie es später erneut.'
    }, 500);
  }
});

// Email verification
app.get('/api/auth/verify-email', async (c) => {
  try {
    const token = c.req.query('token');

    if (!token) {
      return c.json({
        error: 'missing_token',
        message: 'Verifizierungs-Token ist erforderlich'
      }, 400);
    }

    // Find and verify user
    const user = await c.env.DB.prepare(`
      SELECT * FROM users 
      WHERE email_verification_token = ? 
      AND email_verification_expires_at > CURRENT_TIMESTAMP
      AND email_verified = FALSE
    `).bind(token).first();

    if (!user) {
      return c.html(`
        <!DOCTYPE html>
        <html lang="de">
        <head>
            <meta charset="UTF-8">
            <title>Verifizierung fehlgeschlagen</title>
            <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body class="bg-gray-50 flex items-center justify-center min-h-screen">
            <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
                <h1 class="text-2xl font-bold text-red-600 mb-4">❌ Verifizierung fehlgeschlagen</h1>
                <p class="text-gray-600 mb-6">Der Verifizierungs-Link ist ungültig oder abgelaufen.</p>
                <a href="/auth" class="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700">
                    Zur Anmeldung
                </a>
            </div>
        </body>
        </html>
      `);
    }

    // Mark email as verified
    await c.env.DB.prepare(`
      UPDATE users 
      SET email_verified = TRUE, 
          email_verification_token = NULL, 
          email_verification_expires_at = NULL,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(user.id).run();

    // Generate JWT token
    const jwtToken = await sign({
      userId: user.id,
      email: user.email,
      exp: Math.floor(Date.now() / 1000) + 24 * 60 * 60 // 24 hours
    }, c.env.JWT_SECRET);

    // Set auth cookie
    c.header('Set-Cookie', `auth_token=${jwtToken}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=86400`);

    return c.html(`
      <!DOCTYPE html>
      <html lang="de">
      <head>
          <meta charset="UTF-8">
          <title>E-Mail erfolgreich bestätigt</title>
          <script src="https://cdn.tailwindcss.com"></script>
      </head>
      <body class="bg-gray-50 flex items-center justify-center min-h-screen">
          <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
              <h1 class="text-2xl font-bold text-green-600 mb-4">✅ E-Mail bestätigt!</h1>
              <p class="text-gray-600 mb-6">Ihr Konto ist jetzt aktiviert. Willkommen bei Supplement Stack!</p>
              <div class="space-y-4">
                  <a href="/dashboard" class="block w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700">
                      Zum Dashboard
                  </a>
                  <a href="/" class="block w-full bg-gray-200 text-gray-800 py-2 px-4 rounded-md hover:bg-gray-300">
                      Zur Startseite
                  </a>
              </div>
              <script>
                setTimeout(() => window.location.href = '/dashboard', 3000);
              </script>
          </div>
      </body>
      </html>
    `);

  } catch (error) {
    console.error('Email verification error:', error);
    return c.json({
      error: 'internal_server_error',
      message: 'Ein interner Fehler ist aufgetreten'
    }, 500);
  }
});

// Health check - with detailed status
app.get('/api/health', async (c) => {
  try {
    // Test database connection
    const dbTest = await c.env.DB.prepare('SELECT 1 as test').first();
    
    return c.json({ 
      status: 'healthy',
      timestamp: new Date().toISOString(),
      auth: 'enabled',
      database: dbTest ? 'connected' : 'disconnected',
      environment: c.env.ENVIRONMENT || 'unknown',
      mailersend: c.env.MAILERSEND_API_KEY ? 'configured' : 'not configured'
    });
  } catch (error) {
    return c.json({
      status: 'unhealthy',
      error: error.message,
      timestamp: new Date().toISOString()
    }, 500);
  }
})

export default app